package abst;

public interface AI {
	
	public abstract int add(int a,int b);

}
