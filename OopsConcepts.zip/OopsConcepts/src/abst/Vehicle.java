package abst;

public interface Vehicle {
	
	int aa =100;
	
	int weels();
	
	int engine();
	
	String color();
	
	

}
