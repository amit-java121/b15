package abst;

public class Car implements Vehicle{

	@Override
	public int weels() {
		System.out.println("care 4 weels");
		System.out.println(Vehicle.aa);
		return 4;
	}

	@Override
	public int engine() {
		// TODO Auto-generated method stub
		return 1200;
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "green";
	}

}
