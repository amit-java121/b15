package abst;

public class TestAI implements AI{

	@Override
	public int add(int a,int b) {
		
		return a+b;
	}
	
	
	public static void main(String[] args) {
		TestAI testai = new TestAI();
		int sum = testai.add(10, 10);
		System.out.println(sum);
	}

}
