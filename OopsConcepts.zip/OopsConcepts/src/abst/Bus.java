package abst;

public class Bus implements Vehicle{

	@Override
	public int weels() {
		// TODO Auto-generated method stub
		return 6;
	}

	@Override
	public int engine() {
		// TODO Auto-generated method stub
		return 4000;
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "grey";
	}

}
