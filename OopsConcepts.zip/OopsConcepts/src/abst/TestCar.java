package abst;

public class TestCar {
	
	public static void main(String[] args) {
		
		Car car = new Car();
		int hp= car.engine();
		System.out.println(hp);
		
		//Vehicle ve = new Vehicle();
		//
		Bus bus = new Bus();
		System.out.println(bus.engine());
		
	}

}
