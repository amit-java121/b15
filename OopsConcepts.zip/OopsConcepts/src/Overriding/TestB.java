package Overriding;

public class TestB {
	
	public static void main(String[] args) {
		
		B b = new B();
		b.m1();
		
	
	}

}
