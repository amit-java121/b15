package Overriding;

public class TestB {
	
	public static void main(String[] args) {
		
		B b = new B();
		b.m1();
		System.out.println(b.aa);
		
		A a = new B();
		System.out.println(a.aa);
		a.m1();
	
	}

}
