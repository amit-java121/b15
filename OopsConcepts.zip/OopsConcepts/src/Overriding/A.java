package Overriding;

public class A {
	
	public void m1() {
		System.out.println("method called form class A");
	}

}
