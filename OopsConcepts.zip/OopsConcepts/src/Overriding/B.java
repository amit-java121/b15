package Overriding;

public class B extends A{
	
	int bb =20;
	
	public void m1() {
		System.out.println("method called form class B");
	}

}
