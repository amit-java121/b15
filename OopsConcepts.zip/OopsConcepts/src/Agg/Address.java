package Agg;

public class Address {

	private String flatNo;
	private String SocietyName;
	private String area;
	private String city;
	private String state;
	
	public String getFlatNo() {
		return flatNo;
	}
	public void setFlatNo(String flatNo) {
		this.flatNo = flatNo;
	}
	public String getSocietyName() {
		return SocietyName;
	}
	public void setSocietyName(String societyName) {
		SocietyName = societyName;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	@Override
	public String toString() {
		return "Address [flatNo=" + flatNo + ", SocietyName=" + SocietyName + ", area=" + area + ", city=" + city
				+ ", state=" + state + "]";
	}
	
	
}
