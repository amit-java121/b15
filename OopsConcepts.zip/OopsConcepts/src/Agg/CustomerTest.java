package Agg;

public class CustomerTest {
	
	
	public Customer setCustomerData() {
		
		
		Customer customer = new Customer();
		customer.setCustomerId(1001);
		customer.setCustomerName("xpertit");
		
		Address address = new Address();
		address.setFlatNo("c-101");
		address.setArea("magarpatta");
		address.setCity("pune");
		address.setSocietyName("annexe");
		address.setState("MH");
		
		customer.setAddress(address);
		
		//System.out.println("ahahahh "+customer.getAddress().getCity());
		
		
		return customer;
	}

	public static void main(String[] args) {
		CustomerTest customerTest = new CustomerTest();
		Customer cust = customerTest.setCustomerData();
		
		//customer object print here
		System.out.println(cust.toString());
		//System.out.println(cust.getCustomerId());
		//System.out.println(cust.getCustomerName());
		
		System.out.println(cust.getAddress().getCity());
//		if(cust.getAddress().getCity().equalsIgnoreCase("pune")) {
//		
//			System.out.println("we are in pune city:::");
//		}
		
	}
	
	
}
