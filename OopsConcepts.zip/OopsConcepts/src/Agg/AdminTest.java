package Agg;

public class AdminTest {
	
	
	public void printCutomerData() {
		
		CustomerTest customerTest = new CustomerTest();
		Customer custo= customerTest.setCustomerData();
		
		//System.out.println(custo.toString());
		
		String cityName = custo.getAddress().getFlatNo();
		System.out.println(cityName);
		
		
	}
	
	public static void main(String[] args) {
		AdminTest adminTest = new AdminTest();
		adminTest.printCutomerData();
		
		
	}

}
