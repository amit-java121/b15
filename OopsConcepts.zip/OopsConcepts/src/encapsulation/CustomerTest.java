package encapsulation;

public class CustomerTest {

	public static void main(String[] args) {
		
		Customer customer = new Customer(1001, "xpertit", "mumbai", 101001001);
		
		CustomerTest.changeCustomerData(customer);
	}
	
	
	public static void changeCustomerData(Customer customer) {
		
		System.out.println("before change "+customer);
		
		System.out.println("after change "+customer);
	}
}
