package encapsulation;

public class EmployeeTest {
	
	public static void main(String[] args) {
		
		//Employee employee = new Employee(100, "xpertit", "pune", 191991991);
		//System.out.println(employee.toString());
		
		Employee employee = new Employee();
		employee.setEmpId(101);
		employee.setEmpName("Amit");
		employee.setEmpAddress("pune");
		employee.setEmpContactNumber(1001010);
		
		System.out.println(employee);
		
	}

}
