package overloading;

public class Employee {
	
	public String getEmployeeDetails(int employeeId) {
		
		//db call
		//UI
		
		return "Xperit by id";
	}
	
	public String getEmployeeDetails(String employeeEmailId) {
		
		//db call
		//UI
		
		return "Xperit by email id";
	}
	
	

}
