package overloading;

public class EmployeeTEst {
	
	public static void main(String[] args) {
		
		Employee employee = new Employee();
		System.out.println(employee.getEmployeeDetails(1000));
		System.out.println(employee.getEmployeeDetails("amit@gmail.com"));
	}

}
