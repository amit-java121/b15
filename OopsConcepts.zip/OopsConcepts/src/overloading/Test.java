package overloading;

public class Test {
	
	
	public void addition(int a,long b) {
		System.out.println("first method"+a+b);
	}
	
//	public void addition(int a,int b,int c) {
//		System.out.println(a+b);
//	}
	
	public void addition(long a,int b) {
		System.out.println("second method "+a+b);
	}
	

	public static void main(String[] args) {
		
		Test test = new Test();
		//test.addition(10, 10);
		//test.addition(10, 10,10);
	}

}
