package inheri;

public class User {
	
	private int userId;
	private String userName;
	private String userAddress;
	private int panNumber;
	
	public User(int userId, String userName, String userAddress, int panNumber) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userAddress = userAddress;
		this.panNumber = panNumber;
	}

	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public int getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(int panNumber) {
		this.panNumber = panNumber;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userAddress=" + userAddress + ", panNumber="
				+ panNumber + "]";
	}
	

}
