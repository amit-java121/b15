package inheri.Heirachical;

public class C extends A{
	
	int cc =10;
	
	public void m3() {
		System.out.println("m3 called form class C");
	}
	
	public static void main(String[] args) {
		
		C c = new C();
		c.m1();
		
	}

}
