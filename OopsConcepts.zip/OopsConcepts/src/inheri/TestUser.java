package inheri;

public class TestUser {
	
	public static void main(String[] args) {
		
		User user = new User(100, "xpertit", "pune", 1239198188);
		
		
		//System.out.println(user.toString());
		
		NewUser newUser = new NewUser(1000, "xpertit2", "mumbai", 10101001, 1919919991);
		
	}

}
