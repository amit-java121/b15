package inheri;

public class B extends A{
	
	int bb =20;
	
	public void testB() {
		B b =  new B();
		int i = b.test();
		
		System.out.println("class B method testB() ");
	}
	
	public void m1() {
		
		System.out.println("m1 called :::");
	}

}
