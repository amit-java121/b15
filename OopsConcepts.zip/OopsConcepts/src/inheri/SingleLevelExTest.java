package inheri;

public class SingleLevelExTest {
	
	public static void main(String[] args) {
		
		//A a = new A();
		
		//a.test();
		//B b = new B();
		//b.test();
		//b.testB();
		
		A a = new B();
		//B b = new A();
		
		
	}

}
