package inheri;

public class A {
	
	int aa =10;
	String name= "xpert it";
	
	
	public int test() {
		
		System.out.println("class A method test called::");
		 return 10;
	}

}
