package inheri;

public class NewUser extends User{
	long adhaarNumber;

	
	public NewUser(int userId, String userName, String userAddress, int panNumber, long adhaarNumber) {
		super(userId, userName, userAddress, panNumber);
		this.adhaarNumber = adhaarNumber;
	}

	public long getAdhaarNumber() {
		return adhaarNumber;
	}

	public void setAdhaarNumber(long adhaarNumber) {
		this.adhaarNumber = adhaarNumber;
	}
	

}
