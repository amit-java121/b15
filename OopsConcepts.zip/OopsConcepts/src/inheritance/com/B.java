package inheritance.com;

public class B extends A{

	
	int bb =10;
	
	public void m2() {
		System.out.println("m2 called from class B");
	}
}
