package inheritance.com;

public class C extends B{
	
	int cc =10;
	
	public void m3() {
		System.out.println("m3 called from class C");
	}
	


}
