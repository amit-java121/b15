package inheritance.com;

public class TestC {
	
	public static void main(String[] args) {
		
		C c = new C();
		c.m1();
		c.m2();
		c.m3();
		
	}

}
