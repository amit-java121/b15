package com.it.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.it.dao.ILoginDao;
import com.it.model.User;
@Service
@Transactional
public class LoginServiceImpl implements ILoginService{
	
	@Autowired
	ILoginDao loginDao;

	@Override
	public boolean checkUserCredentials(String username, String userpass) {
		// TODO Auto-generated method stub
		User user = loginDao.getUserDetailsByEmailId(username);
		
		if(user != null && user.getUserPass().equalsIgnoreCase(userpass)) {
			return true;
		}
		return false;
	}

	@Override
	public void saveUserDetails(User user) {
		// TODO Auto-generated method stub
		loginDao.saveUserDetails(user);
	}

	@Override
	public List<User> getUserData() {
		// TODO Auto-generated method stub
		return loginDao.getUserData();
	}

	@Override
	public boolean deleteUserById(int id) {
		
		return loginDao.deleteUserById(id);
	}

}
