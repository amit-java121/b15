package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.ILoginDao;
@Service
public class LoginServiceImpl implements ILoginService{
	
	@Autowired
	ILoginDao loginDao;

	@Override
	public void checkUserCredentials(String username, String userpass) {
		// TODO Auto-generated method stub
		loginDao.getUserDetailsByEmailId(username);
		
	}

}
