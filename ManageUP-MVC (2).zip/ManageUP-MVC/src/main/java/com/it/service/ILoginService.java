package com.it.service;

public interface ILoginService {

	void checkUserCredentials(String username, String userpass);

}
