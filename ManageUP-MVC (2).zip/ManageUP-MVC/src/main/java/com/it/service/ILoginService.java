package com.it.service;

import java.util.List;

import com.it.model.User;

public interface ILoginService {

	boolean checkUserCredentials(String username, String userpass);

	void saveUserDetails(User user);

	List<User> getUserData();

	boolean deleteUserById(int id);

}
