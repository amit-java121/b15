package com.it.dao;

public interface ILoginDao {

	void getUserDetailsByEmailId(String username);

}
