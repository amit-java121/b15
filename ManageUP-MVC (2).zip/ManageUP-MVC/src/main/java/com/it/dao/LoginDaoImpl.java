package com.it.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public class LoginDaoImpl implements ILoginDao{
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public User getUserDetailsByEmailId(String username) {
		
		Session session = sessionFactory.openSession();
		 Query query = session.createQuery("from User where userEmail=:username");
		 query.setParameter("username", username);
		 User user = (User)query.getSingleResult();
		 System.out.println(user.toString());
		return user;
	}

	@Override
	public void saveUserDetails(User user) {
		
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(user);
	}

	@Override
	public List<User> getUserData() {

		Session session = sessionFactory.getCurrentSession();
		List listOfUsers = session.createCriteria(User.class).list();
		
		return listOfUsers;
	}

	@Override
	public boolean deleteUserById(int id) {
		Session session = sessionFactory.getCurrentSession();
		try {
		User user = session.get(User.class, id);
		session.delete(user);
		}catch(Exception e) {
			return false;
		}
		return true;
	}

}
