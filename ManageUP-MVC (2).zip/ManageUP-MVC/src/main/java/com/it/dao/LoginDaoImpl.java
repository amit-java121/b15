package com.it.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class LoginDaoImpl implements ILoginDao{
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public void getUserDetailsByEmailId(String username) {
		
		Session session = sessionFactory.openSession();
		 Query query = session.createQuery("from User where userEmail=:username");
		 query.setParameter("username", username);
		 List user = query.getResultList();
		 System.out.println(user.toString());
		
	}

}
