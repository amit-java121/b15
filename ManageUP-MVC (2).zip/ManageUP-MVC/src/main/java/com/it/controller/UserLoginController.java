package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.it.service.ILoginService;

@Controller
public class UserLoginController {
	
	@Autowired
	ILoginService loginService;
	
	@GetMapping("/")
	public String loginPage() {
	System.out.println("login page called::");
		return "login";
	}
	
	@GetMapping("/login")
	public String login(@RequestParam("userName") String username,@RequestParam("userPass") String userpass) {
	System.out.println("user credentials:: "+username+" "+userpass);
	   loginService.checkUserCredentials(username,userpass);
		return "login";
	}
	

}
