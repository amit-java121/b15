package com;

import java.util.Iterator;
import java.util.Vector;

public class VectorEx {
	
	public static void main(String[] args) {
		
		Vector<String> vector = new Vector<>();
		vector.addElement("deepak");
		vector.addElement("deepak1");
		vector.addElement("deepak2");
		vector.addElement("deepak3");
		
		
		Iterator<String> itr = vector.iterator();
		
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		
//		for(String ve:vector) {
//			System.out.println(ve);
//		}
	}

}
