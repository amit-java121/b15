package com;

import java.util.ArrayList;

public class ArrayListEx {
	
	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("abc");
		list.add("abc");
		list.add("xpertit1");
		list.add("xpertit3");
		
		
		ArrayList<String> list2 = new ArrayList<String>();
		
		list2.add("abc");
		list2.add("abc1");
		list2.add("abc2");
		
		//list.addAll(0,list2);
		
		
		//list.clear();
		
//		if(list.contains("abc2")) {
//			
//			System.out.println(list.get(list.indexOf("abc2")));
//			System.out.println("yes it is present");
//		}
		
		System.out.println(list.containsAll(list2));
		
//		for(String l:list2) {
//			System.out.println(l);
//		}
		
//		for(int i=0;i<list.size();i++) {
//			String str = (String)list.get(i);
//			System.out.println(str);
//			
//		}
		
	}

}
