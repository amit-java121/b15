package com;

import java.util.LinkedList;
import java.util.List;

public class LinkedListEx {
	
	public static void main(String[] args) {
		LinkedList<String> linkedList = new LinkedList<>();
		
		linkedList.add("abc");
		linkedList.add("xyz");
		linkedList.add("abc2");
		linkedList.add("abc3");
		
		  LinkedList<String> linkedList2 = new LinkedList<>();
				
		  linkedList2.add("abc");
		  linkedList2.add("xyz");
		  linkedList2.add("xyz1");
		  linkedList2.add("xyz2");
		
		//linkedList.retainAll(linkedList2);
		
		List<String> subList = linkedList.subList(0, 3);
		
		for(String list:subList) {
			System.out.println(list);
		}
		
	}

}
