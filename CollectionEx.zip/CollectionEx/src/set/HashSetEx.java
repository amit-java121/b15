package set;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class HashSetEx {
	
	public static void main(String[] args) {
		
//		HashSet<String> hashSet = new HashSet<>();
//		hashSet.add("abc");
//		hashSet.add("abc1");
//		hashSet.add("abc");
//		hashSet.add("deepak");
//		hashSet.add("ajay");
//		hashSet.add("rutuja");
//		
//		for(String set:hashSet) {
//			System.out.println(set);
//		}
		
		
		LinkedHashSet<String> linkedHash = new LinkedHashSet<>();
		linkedHash.add("abc");
		linkedHash.add("abc1");
		linkedHash.add("abc");
		linkedHash.add("deepak");
		linkedHash.add("ajay");
		linkedHash.add("rutuja");
		
		for(String set:linkedHash) {
			System.out.println(set);
		}
		
	}

}
