package set;

import java.util.TreeSet;

public class TreeSetEx {
	
	public static void main(String[] args) {
		
		TreeSet<String> treeSet = new TreeSet();
		
		treeSet.add("abc");
		treeSet.add("abc1");
		treeSet.add("abc");
		treeSet.add("deepak");
		treeSet.add("ajay");
		treeSet.add(null);
		
		System.out.println(treeSet);
		System.out.println(treeSet.floor("ajayy"));
		
//		TreeSet<Integer> tree = new TreeSet<Integer>();
//		tree.add(100);
//		tree.add(99);
//		tree.add(98);
//		tree.add(101);
//		tree.add(96);
//		
//		System.out.println(tree.floor(97));
//		System.out.println(tree.ceiling(97));
	}

}
