package map;

import java.util.HashMap;

public class HashMapEx {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String> hashmap = new HashMap<>();
		
		hashmap.put(100, "sudan");
		hashmap.put(105, "deepak");
		hashmap.put(102, null);
		hashmap.put(101, null);
		hashmap.put(null, "abc");
		hashmap.put(null, "abc1111");
		//System.out.println(hashmap.getOrDefault(110, "xyz"));
		
		//System.out.println(hashmap.putIfAbsent(115, "pqr"));
		//System.out.println(hashmap.replace(102, "value"));
		System.out.println(hashmap.keySet());
		System.out.println(hashmap.values());
		//System.out.println(hashmap);
//		for(Entry<Integer, String> map:hashmap.entrySet()) {
//			System.out.println(map.getKey() +" "+map.getValue());
//		}
		
	}

}
