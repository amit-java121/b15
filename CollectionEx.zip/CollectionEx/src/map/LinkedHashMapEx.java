package map;

import java.util.LinkedHashMap;

public class LinkedHashMapEx {
	
	public static void main(String[] args) {
		
		LinkedHashMap<String, String> linkedMap = new LinkedHashMap<>();
	
		linkedMap.put("abc", "xyz");
		linkedMap.put("abc1", "xyz1");
		linkedMap.put("abc2", "xyz2");
		
		System.out.println(linkedMap);
	}
	
	
	

}
