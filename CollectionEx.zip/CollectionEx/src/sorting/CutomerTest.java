package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CutomerTest {
	
	public ArrayList<Customer> prepareData() {
		
		Customer customer = new Customer(1000, "Anuj", 20, "pune");
		Customer customer1 = new Customer(1005, "deepak", 20, "pune");
		Customer customer2 = new Customer(1002, "Ingle", 20, "pune");
		Customer customer3 = new Customer(1003, "Archana", 20, "pune");
		
		ArrayList<Customer> customerList = new ArrayList<>();
		customerList.add(customer);
		customerList.add(customer1);
		customerList.add(customer2);
		customerList.add(customer3);
		
		return customerList;
		
	}
	
	public static void main(String[] args) {
		CutomerTest ct = new CutomerTest();
		ArrayList<Customer> listOfCutomers = ct.prepareData();
		
		//Collections.sort(listOfCutomers,  new CutomerNameSorting());
		Collections.sort(listOfCutomers,  new CustomerIdSorting());
		System.out.println(listOfCutomers);
		//unmodifiableList
		List<Customer> readOnlyList = Collections.unmodifiableList(listOfCutomers);
		System.out.println(readOnlyList);
		//Customer customer = new Customer(1010, "Anuj", 20, "pune");
		//readOnlyList.add(customer);
		System.out.println(readOnlyList);
		//synchronized
		List<Customer> synchList = Collections.synchronizedList(readOnlyList);
		System.out.println(synchList);
		
		
	}

}
