package sorting;

public class Employee implements Comparable<Employee>{
	
	private int empId;
	private String empName;
	private int empAge;
	private String address;
	
	public Employee(int empId, String empName, int empAge, String address) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAge = empAge;
		this.address = address;
	}
	
	@Override
	public int compareTo(Employee o) {
		
		return empName.compareToIgnoreCase(o.getEmpName());
		
	}
	
//	@Override
//	public int compareTo(Employee o) {
//		
//		if( empId < o.getEmpId()) {
//			return 1;
//		}else if( empId > o.getEmpId()) {
//			return -1;
//		}else {
//			return 0;
//		}
//		
//	}
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpAge() {
		return empAge;
	}
	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empAge=" + empAge + ", address=" + address
				+ "]";
	}
	
	
	
	

}
