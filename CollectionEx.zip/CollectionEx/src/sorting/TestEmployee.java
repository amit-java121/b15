package sorting;

import java.util.ArrayList;
import java.util.Collections;

public class TestEmployee {
	
	
	public ArrayList<Employee> setData() {
		
		Employee employee = new Employee(105, "Anuj", 22, "pune");
		Employee employee1 = new Employee(101, "Ingle", 24, "pune");
		Employee employee2 = new Employee(104, "Deepak", 22, "mumbai");
		Employee employee3 = new Employee(102, "Ajay", 22, "pune");
		
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(employee);
		empList.add(employee1);
		empList.add(employee2);
		empList.add(employee3);
		
		return empList;
	}
	
	public static void main(String[] args) {
		TestEmployee te = new TestEmployee();
		ArrayList<Employee> listOfEmployee= te.setData();
		
		//sort
		
//		ArrayList<String> list = new ArrayList<>();
//		list.add("Anuj");
//		list.add("Ajay");
//		list.add("pqr");
//		Collections.sort(list);
//		System.out.println(list);
		Collections.sort(listOfEmployee);
		
		System.out.println(listOfEmployee);
	}

}
