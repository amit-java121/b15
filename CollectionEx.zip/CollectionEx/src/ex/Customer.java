package ex;

public class Customer {
	
	private int customerAccount;
	private String cusotmerName;
	private String customerBankName;
	private long mobileNumber;
	
	
	public Customer(int customerAccount, String cusotmerName, String customerBankName, long mobileNumber) {
		super();
		this.customerAccount = customerAccount;
		this.cusotmerName = cusotmerName;
		this.customerBankName = customerBankName;
		this.mobileNumber = mobileNumber;
	}
	public int getCustomerAccount() {
		return customerAccount;
	}
	public void setCustomerAccount(int customerAccount) {
		this.customerAccount = customerAccount;
	}
	public String getCusotmerName() {
		return cusotmerName;
	}
	public void setCusotmerName(String cusotmerName) {
		this.cusotmerName = cusotmerName;
	}
	public String getCustomerBankName() {
		return customerBankName;
	}
	public void setCustomerBankName(String customerBankName) {
		this.customerBankName = customerBankName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "Customer [customerAccount=" + customerAccount + ", cusotmerName=" + cusotmerName + ", customerBankName="
				+ customerBankName + ", mobileNumber=" + mobileNumber + "]";
	}
	
	

}
