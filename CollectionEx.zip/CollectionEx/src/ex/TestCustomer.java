package ex;

import java.util.HashMap;

public class TestCustomer {
	
	public Customer printCustomerDetails(int account) {
		
		CustomerData customerData = new CustomerData();
		
		HashMap<Integer, Customer> newHashMap = new HashMap<>();
		newHashMap = customerData.prepareCustomerData();
		 
		Customer c = newHashMap.get(account);
		
		 //System.out.println(newHashMap.toString());
		return c;
	}
	
	
	public static void main(String[] args) {
		TestCustomer testCustomer = new TestCustomer();
		Customer cust = testCustomer.printCustomerDetails(444444);
		System.out.println(cust);
	}
	

}
