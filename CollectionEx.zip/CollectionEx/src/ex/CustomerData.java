package ex;

import java.util.HashMap;

public class CustomerData {
	
	public HashMap<Integer, Customer> prepareCustomerData() {
		
		Customer customer1 = new Customer(313133131, "Ingle","HDFC Bank" , 11111111111l);
		Customer customer2 = new Customer(222222343, "Deepak","HDFC Bank" , 11111111111l);
		Customer customer3 = new Customer(444444321, "Ajay","HDFC Bank" , 11111111111l);
		Customer customer4 = new Customer(55543233, "Sudan","HDFC Bank" , 11111111111l);
		
		HashMap<Integer, Customer> customerMap = new HashMap<>();
		customerMap.put(customer1.getCustomerAccount(), customer1);
		customerMap.put(customer2.getCustomerAccount(), customer2);
		customerMap.put(customer3.getCustomerAccount(), customer3);
		customerMap.put(customer4.getCustomerAccount(), customer4);
			
		return customerMap;
	}

}
