package method;

public class MethodEx {
	
	public static String m1() {
		
		//String str = m2();
		
		return "m1 called ";
		
	}
	
	
	public String m2() {

		m1();
		return "m2 called";
	}

}
