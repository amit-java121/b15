package method;

public class TestMethod {
	
	
	public void m3() {
		System.out.println("m3 called::");
		
		//m1()
		//m2()
		MethodEx me = new MethodEx();
		 //me.m1();
		 String str= me.m1();
		 System.out.println(str);
		//System.out.println(me.m2());
		
		
	}
	
	public static void main(String[] args) {
		
		TestMethod tm = new TestMethod();
		tm.m3();
		
//		MethodEx me = new MethodEx();
//		me.m1();
//		me.m2();
		
		
	}

}
