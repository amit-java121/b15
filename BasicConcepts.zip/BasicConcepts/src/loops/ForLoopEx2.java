package loops;

public class ForLoopEx2 {
	
	public static void main(String[] args) {
		
		aa:
		for(int j=0; j<2; j++) {
		
				for(int i=0; i<10; i++) {
				
					if(i==5) {
						break aa;
					}
					
					System.out.println(i);
				}
		}
		
	}

}
