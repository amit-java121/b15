package loops;

public class ContinueEx {
	
	public static void main(String[] args) {
		
		dd:
			for(int j=0; j<2; j++) {
			
					for(int i=0; i<10; i++) {
					
						if(i==5) {
							continue dd;
						}
						
						System.out.println(i);
					}
			}
			
		
	}

}
