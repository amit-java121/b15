package loops;

import java.util.ArrayList;
import java.util.List;

public class ForLoopEx {
	
	
	public static void main(String[] args) {
		
		
		int[] array = new int[5];
		array[0]=10;
		array[1]=20;
		array[2]=30;
		array[3]=40;
		array[4]=50;
		
//		for(int i=0; i<array.length;i++) {
//			
//			System.out.println(array[i]);
//		}
		
		//foreach
		
		List<String> list = new ArrayList<>();
		list.add("abc");
		list.add("abc1");
		list.add("abc2");
		list.add("abc3");
		
		
		for(int i=0; i<list.size();i++) {
		
			System.out.println(list.get(i));
		}
		
		for(String li: list) {
			System.out.println(li);
		}
		
	}

}
