package loops;

public class TestWhileLoop {
	
	public void test(boolean flag) {
		
		while(flag) {
			int a=10;
			System.out.println("some logic:::");
			if(a==10) {
				flag=false;
			}
			
		}
		
		
	}
	
	public void testDoWhile() {
		int a=5;
		
		do {
			
			System.out.println("do executed::");
			a++;
			
		}while(true);
	}
	
	public static void main(String[] args) {
		TestWhileLoop testWhileLoop = new TestWhileLoop();
		//testWhileLoop.test(true);
		testWhileLoop.testDoWhile();
	}

}
