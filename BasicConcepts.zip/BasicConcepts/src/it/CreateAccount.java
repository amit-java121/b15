package it;

public class CreateAccount {
	
	public static void main(String[] args) {
		
		Customer customer = new Customer(100,"Xyz","pune");
		
	  String message = customer.customerAccountCreation();
	  
	  System.out.println(message);
		
		
	}

}
