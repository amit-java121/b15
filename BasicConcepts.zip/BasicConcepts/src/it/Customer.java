package it;

public class Customer {
	
	int custmerId;
	String customerName;
	String customerAddress;
	
	
	public Customer(int custmerId, String customerName, String customerAddress) {
		super();
		this.custmerId = custmerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
	}





	public String customerAccountCreation() {
		
		System.out.println("customer account created:::");
		
		
		return "Account created::";
		
	}

}
