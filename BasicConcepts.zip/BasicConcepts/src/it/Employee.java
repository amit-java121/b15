package it;

public class Employee {
	
	int employeeId;
	String employeeName;
	long employeeMobileNumber;
	String address;
	
	

	public void employeeWork() {
		
		System.out.println("we are in employeeWork method:::");
		//logic 
		
		employeeId =100;
		employeeName = "deepak";
		employeeMobileNumber = 101001010;
		address = "pune";
		
	}
	
	
	

}
