package it;

public class TestEmployee {
	
	
	
	public static void main(String[] args) {
		
		Employee emp = new Employee();
		emp.employeeWork();
		
		System.out.println(emp.employeeId);
		System.out.println(emp.employeeName);
		System.out.println(emp.employeeMobileNumber);
		System.out.println(emp.address);
		
	}

}
