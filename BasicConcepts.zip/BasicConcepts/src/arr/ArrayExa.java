package arr;

public class ArrayExa {
	
	
	public static void main(String[] args) {
		
		int[] array =  new int[10];
		
		int arr[] =  new int[5];
		int[] arra = {10,20,30,40,50};
		
		for(int aa:arra) {
			System.out.println(aa);
		}
		
	}

}
