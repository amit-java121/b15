package arr;

import java.util.Scanner;

public class TestArray {
	
	public static void main(String[] args) {
		
		int[] array =  new int[5];
		
		String[] strArray = new String[5];
		Scanner sc = new Scanner(System.in);
		String values = sc.nextLine();
		
		for (int i = 0; i < 4; i++) {
		
			strArray[i] = sc.nextLine();
		}
	}

}
