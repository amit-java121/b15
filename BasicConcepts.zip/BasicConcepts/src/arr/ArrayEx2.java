package arr;

public class ArrayEx2 {
	
	public static void main(String[] args) {
		
		int[][] array = new int[3][3];
		
		//array[0][0] =10;
		
		
		int[][] array1 = {{1,2,3},{4,5,6},{7,8,9}};
		
		for(int i=0;i<3;i++) {
			
			for(int j=0;j<3;j++) {
				System.out.print(array1[i][j]+" ");;
			}
			
			System.out.println();
		}
		
		
	}

}
