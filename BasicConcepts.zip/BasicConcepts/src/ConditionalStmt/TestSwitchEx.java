package ConditionalStmt;

public class TestSwitchEx {
	
	public static void main(String[] args) {
		TestSwitch testSwitch = new TestSwitch();
		
		String formattedDate = testSwitch.getDate("12-JUN-2023");
		
		System.out.println(formattedDate);
		
	}

}
