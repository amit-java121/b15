package ConditionalStmt;

public class IfStmtEx {
	
	public void testIf() {
		System.out.println("some logic here ");
		
		int age =20;
		int aa = 10;
		
		if(age > 10) {
			
			if(aa >=10) {
				System.out.println("nested if condtiion");
			}else {
				System.out.println("nested else::");
			}
			
			
		}else {
			
			System.out.println("inside else::");
		}
		
		
		
		System.out.println("after if ");
		
		
	}
	
	
	public static void main(String[] args) {
		IfStmtEx stmt = new IfStmtEx();
		stmt.testIf();
	}

}
