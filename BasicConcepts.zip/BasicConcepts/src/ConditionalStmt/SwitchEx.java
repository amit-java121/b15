package ConditionalStmt;

public class SwitchEx {
	
	public void testSwitch(int a) {
		
		//String str ="hello";
		//char c ='A';
		//long l =100l;
		//double d =100.10;
		
		switch (a) {
		case 10:
			System.out.println("case : "+a);
			break;
			
		case 20:
			System.out.println("case : "+a);
			break;
			
		case 30:
			System.out.println("case : "+a);
			break;

		default:
			System.out.println("default : "+a);
			break;
		}
		
	}
	
	public static void main(String[] args) {
		SwitchEx se = new SwitchEx();
		se.testSwitch(60);
	}

}
