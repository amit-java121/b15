package ConditionalStmt;

public class ElseIfStmt {
	
	public void testElseIf(int a) {
		
		//10,20,30,40,50
		
		if(a == 10) {
		
			System.out.println("inside if "+a);
		}else if(a == 20) {
			System.out.println("inside else if "+a);
		}else if(a == 30) {
			System.out.println("inside else if "+a);
		}else {
			System.out.println("inside else::  ");
		}
		
		
	}
	
	
	public static void main(String[] args) {
		ElseIfStmt ei = new ElseIfStmt();
		ei.testElseIf(60);
	}

}
