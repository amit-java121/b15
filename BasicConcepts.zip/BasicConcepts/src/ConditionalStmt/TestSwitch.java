package ConditionalStmt;

public class TestSwitch {
	
	public String test(String monthName) {
		
		String strMonthName="";
		
		switch (monthName) {
		case "JAN":
			strMonthName="01";
			break;
			
		case "FEB":
			strMonthName="02";
			break;
			
		case "MAR":
			strMonthName="03";
			break;
		case "APR":
			strMonthName="04";
			break;
		case "MAY":
			strMonthName="05";
			break;
		case "JUN":
			strMonthName="06";
			break;

		default:
			strMonthName="00";
			break;
		}
		
		return strMonthName;
		
	}
	
	
	public String getDate(String date) {
		
		String monthNameStr= date.substring(3, 6);
		
		 String monthNo = test(monthNameStr);
		 
		 String newdate = date.replace(monthNameStr, monthNo);
		 
		return newdate;
	}
	

}
