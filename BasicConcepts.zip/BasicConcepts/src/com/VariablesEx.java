package com;

public class VariablesEx {
	
	int a =10;
	static int b = 20;
	
	
	public void m1() {
		
		int aa =30;
		System.out.println(a);
		System.out.println(aa);
		
		System.out.println(b);
		m2();
		
		
	}
	
	public static void m2() {
		
		VariablesEx vv = new VariablesEx();
		  vv.m1();
		
		//System.out.println(a);
		System.out.println(b);
		System.out.println("m2 called::");
	}
	

}
