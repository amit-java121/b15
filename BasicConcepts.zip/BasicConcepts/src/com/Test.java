package com;

public class Test {
	
	public static void main(String[] args) {
		
		//System.out.println("hiiii");
		int a = 10;
		int b = 20;
		int sum = a+b;
		
	   System.out.println(sum);
		
	}

}
