package com;

public class TestVariables {
	
	public static void main(String[] args) {
		
		//VariablesEx ve = new VariablesEx();
		//System.out.println(ve.a);
		//ve.m1();
		System.out.println(VariablesEx.b);
		VariablesEx.m2();
		
	}

}
