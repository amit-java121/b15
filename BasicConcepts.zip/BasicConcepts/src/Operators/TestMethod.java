package Operators;

public class TestMethod {
	
	
	public String checkUserAge(int age) {
		
		if(age > 20) {
			return "you are 20 years old";
		}else {
			return "you are not 20 years old";
		}
		
		
		
	}
	
	
	public static void main(String[] args) {
		
		TestMethod testMethod =  new TestMethod();
		String value = testMethod.checkUserAge(30);
		System.out.println(value);
	}

}
