package Operators;

public class Test {
	
	public static void main(String[] args) {
		
		
		int a =10;
//		System.out.println(++a);//11
//		System.out.println(a++);//10//11
//		System.out.println(a);//10//12
//		System.out.println(--a);//11
//		System.out.println(a);//11
//		System.out.println(a--);//11
//		System.out.println(a);//10
		int b =25;
		
		//System.out.println(a+b);
		//int c =b%a;
		//System.out.println(c);
		
		
		//System.out.println(b==a);
		//
		//a *=30;
		//System.out.println(a);
		
		Test test = new Test();
//		test.m1();
		test.m2(25);
		
//		int[] arrays = new int[10];
//		arrays[0] = 10;
		
//		int[] intArray = {10,20,30,40,50};
//		
//		for(int i=0; i < intArray.length; i++) {
//		
//			System.out.println(intArray[i]);
//		}
//		
//		for(int arr:intArray) {
//			System.out.println(arr);
//		}
		
		
		//long // Long
	}
	
	
	public void m1() {
		
		int aa =10;
		int bb = 20;
		if(aa > 5 && bb > 25) {
			System.out.println("if called::");
		}
		
//		if(aa > 5 || bb > 25) {
//			System.out.println("if called::");
//		}
		
		
//		if(aa > 5 & bb > 25) {
//		
//			System.out.println("bitwise operators executed:::");
//		}
//		
//		if(aa > 5 | bb > 25) {
//			System.out.println("bitwise operators executed:::");
//		
//		}
		
		if(aa <= 5 && bb >= 25) {
			System.out.println("if called::");
		}
		
	}
	
	public void m2(int age) {
		int num = 0;

		System.out.println(num);

		if (age > 20) {
			num = 10;
		} else {
			num = 30;
		}

		// int num= (age>20 ? 10 : 30);

		System.out.println(num);

	}

}
