package op;

public class TestOp2 {
	
	int sum;
	
	public void addition(int a,int b) {
		sum = a+b;
	}
	
	
	public void multiplication() {
		int constt =10;
		sum *= constt;
		
	}
	
	
	
	public static void main(String[] args) {
		
		int a =10;
		int b=20;
		TestOp2 to = new TestOp2();
		 to.addition(a, b);
		to.multiplication();
		System.out.println(to.sum);
	}

}
