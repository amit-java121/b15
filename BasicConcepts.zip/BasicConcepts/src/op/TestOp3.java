package op;

public class TestOp3 {

	public int addition(int a, int b) {
		return a + b;
	}

	public int multiplication(int sum, int multi) {
		return sum *= multi;

	}

	public static void main(String[] args) {

		TestOp3 to = new TestOp3();
		int sum = to.addition(10, 20);

		int multi = to.multiplication(sum, 20);
		System.out.println(multi);
	}

}
