package op;

public class TestOp {
	
	public static void main(String[] args) {
		
		
//		int a =10;
//		System.out.println(a++);//11
//		System.out.println(++a);//11,10
//		System.out.println(a++);//12,10
//		System.out.println(a);
		
		//int b=20;
		//System.out.println(b);
		
		//b=30;
		
//		int c =40;
//		c *=10;
//		System.out.println(c);
		
//		int a =10;
//		int b =10;
//		
//		if(a>b && b>a) {
//			System.out.println("inside if");
//		}else {
//			System.out.println("inside else");
//		}
		
//		String str ="xyz";
//		String str1 = "Xyz";
//		System.out.println(str.equalsIgnoreCase(str1)?"inside if":"inside else");
		
		
		
		
	}

}
