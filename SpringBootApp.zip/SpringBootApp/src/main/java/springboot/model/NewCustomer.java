package springboot.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "customer")
public class NewCustomer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "customer_id",nullable = false,unique = true)
	private int customerId;
	
	@Column(name = "customer_name",nullable = true)
	private String customerName;
	
	@Column(name = "customer_contact",nullable = true)
	private int customerContact;
	
	@OneToMany(mappedBy = "newCustomer",cascade = CascadeType.ALL)
	private List<Orders> orders;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(int customerContact) {
		this.customerContact = customerContact;
	}

	public List<Orders> getOrders() {
		return orders;
	}

	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}

	@Override
	public String toString() {
		return "NewCustomer [customerId=" + customerId + ", customerName=" + customerName + ", customerContact="
				+ customerContact + ", orders=" + orders + "]";
	}

	

}
