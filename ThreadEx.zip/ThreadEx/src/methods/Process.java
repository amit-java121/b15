package methods;

import java.util.Scanner;

public class Process {
	
	public void Test() throws InterruptedException {
		System.out.println(" Test Thread "+Thread.currentThread().getName());
		synchronized (this) {
			wait(1000);
		}
		
		System.out.println("Thread resumed:::");
	}
	
	public void Test2() throws InterruptedException {
		Thread.sleep(2000);
		System.out.println("calling to notify:::"+Thread.currentThread().getName());
		//Scanner sc = new Scanner(System.in);
	//	System.out.println("press any key");
		//sc.nextLine();
//		Thread.sleep(5000);
//		synchronized (this) {
//			 this.notify();
//		}
		
		System.out.println("after notify call");
	}

}
