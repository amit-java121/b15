package transaction;

public class Transaction extends Thread{
	
	static int balance = 1000;

	@Override
	public void run() {
		for(int i=0; i<10; i++) {
			withdrawn(150);
		}
		
		
	}

	private static synchronized void withdrawn(int amt) {
		
		System.out.println("thread "+Thread.currentThread().getName());
		
		if(balance > amt) {
			balance  = balance-amt;
			System.out.println("remaining amt "+balance);
		}else {
			
			System.out.println("insufficient fund::");
			
		}
		
		
	}
	
	
}
