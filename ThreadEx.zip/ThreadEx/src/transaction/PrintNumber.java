package transaction;

public class PrintNumber {
	
	public void print() {
		
		System.out.println("num 1");
		System.out.println("num 2");
		System.out.println("num 3");
		System.out.println("num 4");
		
		synchronized (this) {
			for(int i=0;i<5;i++) {
				System.out.println("i "+i);
			}
		}
		
		
		System.out.println("num 5");
		
		System.out.println("num 6");
		System.out.println("num 7");
		System.out.println("num 8");
		
		
	}

}
