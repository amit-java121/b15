package transaction;

public class Task extends Thread{
	
	PrintNumber pn;

	public Task(PrintNumber pn) {
		this.pn = pn;
	}
	
	@Override
	public void run() {
		pn.print();
	}
}
