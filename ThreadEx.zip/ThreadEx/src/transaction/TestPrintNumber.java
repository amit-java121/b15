package transaction;

public class TestPrintNumber {
	
	
	public static void main(String[] args) {
		
		PrintNumber pn = new PrintNumber();
		
		Task task = new Task(pn);
		task.start();
		
		
		Task2 task2  = new Task2(pn);
		task2.start();
		
	}

}
