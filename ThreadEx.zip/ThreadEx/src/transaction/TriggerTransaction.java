package transaction;

public class TriggerTransaction {
	
	
	public static void main(String[] args) {
		
		Transaction tr = new Transaction();
		tr.setName("HDFC Bank");
		tr.start();
		
		
		Transaction tr1 = new Transaction();
		tr1.setName("ATM");
		tr1.start();
		
	}

}
