package com;

public class Job2 extends Thread{
	
	@Override
	public void run(){
		System.out.println(Thread.currentThread().getName());
		for(int i=20;i<30; i++) {
			System.out.println("i "+i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
