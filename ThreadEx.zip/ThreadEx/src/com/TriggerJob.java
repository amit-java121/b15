package com;

public class TriggerJob {
	
	public static void main(String[] args) throws InterruptedException {
		
		Thread.currentThread().setName("main thread:");
		System.out.println(Thread.currentThread().getName());
		for(int i =0;i<10; i++) {
			System.out.println(" i "+i);
		}
		
		Job job = new Job();
		job.setName("HDFC Bank");
		job.start();
		 
		
		Job2 job2 = new Job2();
		job2.setName("ICICI bank");
		job2.start();
	
		System.out.println(Thread.currentThread().getName());
		for(int i=30;i<40;i++) {
			System.out.println(i);
		}
		
	}

}
