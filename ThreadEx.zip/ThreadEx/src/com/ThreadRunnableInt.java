package com;

public class ThreadRunnableInt implements Runnable {

	@Override
	public void run() {
		for(int i=0;i<10; i++) {
			System.out.println(i);
		}
		
	}
	
	
	
	public static void main(String[] args) {
		
		ThreadRunnableInt tr = new ThreadRunnableInt();
		
		Thread  th = new Thread(tr);
		th.start();
		
		
	}
	

}
