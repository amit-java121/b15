package com.it.service;

import com.it.model.User;

public interface ILoginService {

	boolean checkUserCredentials(String username, String userpass);

	void saveUserDetails(User user);

}
