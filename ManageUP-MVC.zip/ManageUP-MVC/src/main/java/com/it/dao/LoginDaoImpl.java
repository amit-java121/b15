package com.it.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public class LoginDaoImpl implements ILoginDao{
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public User getUserDetailsByEmailId(String username) {
		
		Session session = sessionFactory.openSession();
		 Query query = session.createQuery("from User where userEmail=:username");
		 query.setParameter("username", username);
		 User user = (User)query.getSingleResult();
		 System.out.println(user.toString());
		return user;
	}

	@Override
	public void saveUserDetails(User user) {
		
		Session session = sessionFactory.getCurrentSession();
		session.save(user);
	}

}
