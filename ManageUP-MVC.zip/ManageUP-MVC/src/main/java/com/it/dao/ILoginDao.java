package com.it.dao;

import com.it.model.User;

public interface ILoginDao {

	User getUserDetailsByEmailId(String username);

	void saveUserDetails(User user);

}
