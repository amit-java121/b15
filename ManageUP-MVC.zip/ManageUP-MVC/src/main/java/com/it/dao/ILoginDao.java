package com.it.dao;

import java.util.List;

import com.it.model.User;

public interface ILoginDao {

	User getUserDetailsByEmailId(String username);

	void saveUserDetails(User user);

	List<User> getUserData();

	boolean deleteUserById(int id);

	User updateUser(int id);

}
