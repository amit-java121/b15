package com.it.controller;

import javax.persistence.PostLoad;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.User;
import com.it.service.ILoginService;

@Controller
public class UserLoginController {
	
	@Autowired
	ILoginService loginService;
	
	@GetMapping("/")
	public String loginPage() {
	System.out.println("login page called::");
		return "login";
	}
	
	@GetMapping("/registration")
	public ModelAndView userRegistration() {
		ModelAndView model = new ModelAndView("registration", "user", new User());
		
		return model;
	}
	
	@GetMapping("/login")
	public String login(@RequestParam("userName") String username,@RequestParam("userPass") String userpass) {
	System.out.println("user credentials:: "+username+" "+userpass);
	   boolean flag = loginService.checkUserCredentials(username,userpass);
	   if(flag) {
		   return "success";
	   }
		return "login";
	}
	
	@PostMapping("/save")
	public String saveUserData(@ModelAttribute User user) {
		System.out.println("save metho called "+user.toString());
		loginService.saveUserDetails(user);
		return "success";
	}

}
