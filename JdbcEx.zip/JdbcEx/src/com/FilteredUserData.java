package com;

import java.util.List;

public class FilteredUserData {
	
	public static void main(String[] args) {
		
		UserData ud = new UserData();
		List<User> filteredUserList= ud.filterUserData("nagpur");
		
		System.out.println(filteredUserList.toString());
		//getUserDataBuCityName();
		
	}
	
	
	public static void getUserDataBuCityName() {
		
		JdbcConnection jdbcc = new JdbcConnection();
		List<User> listOfUsers = jdbcc.getAllUserDataByCityName("nagapur");
		System.out.println(listOfUsers.toString());
		
	}

}
