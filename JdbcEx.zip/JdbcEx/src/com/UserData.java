package com;

import java.util.ArrayList;
import java.util.List;

public class UserData {
	
	public static void main(String[] args) {
		
		JdbcConnection jdbcc = new JdbcConnection();
		List<User> listOfusers = jdbcc.getAllUserData();
		
		for(User user:listOfusers) {
			
			if(user.getUserName().equalsIgnoreCase("om")) {
				System.out.println(user.getId());
				System.out.println(user.getUserName());
				System.out.println(user.getUserPass());
				System.out.println(user.getGender());
				System.out.println(user.getMobileNo());
			}
			
		}
		
		//System.out.println(listOfusers.toString());
		
		
		
	}
	
	public List<User> filterUserData(String cityName) {
		
		List<User> filterList = new ArrayList<>();
		
		JdbcConnection jdbcc = new JdbcConnection();
		List<User> listOfusers = jdbcc.getAllUserData();
		
		
		for(User user:listOfusers) {
			
			if(user.getUserAddress().equalsIgnoreCase(cityName)) {
//				
//				System.out.println(user.getId());
//				System.out.println(user.getUserName());
//				System.out.println(user.getUserPass());
//				System.out.println(user.getGender());
//				System.out.println(user.getMobileNo());
				
				filterList.add(user);
			}
			
		}
		return filterList;
	}

}
