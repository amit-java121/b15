package com;

public class TestCommonOperations {
	
	
	public static void main(String[] args) {
		//saveUserData();
		//deleteUserrecord();
		updateUserRecord();
	}
	
	public static void saveUserData() {
		JdbcConnection connection = new JdbcConnection();
		
		User user = new User();
		user.setId(100);
		user.setUserName("Ved");
		user.setGender("male");
		user.setMobileNo(191991919);
		user.setUserPass("ved");
		user.setUserAddress("mumbai");
		
		String msg = connection.saveUserData(user);
		System.out.println(msg);
	}
	
	public static void deleteUserrecord() {
		JdbcConnection connection = new JdbcConnection();
		String msg = connection.deleteUserRecord(100);
		System.out.println(msg);
	}
	
	public static void updateUserRecord() {
		JdbcConnection connection = new JdbcConnection();
		User user =  new User();
		user.setId(2);
		user.setMobileNo(333333333);
		user.setUserAddress("hadapsar");
		
		String msg = connection.updateUserData(user);
		System.out.println(msg);
	}

}
