package com;

import java.util.ArrayList;
import java.util.List;

public class TestCommonOperations {
	
	
	public static void main(String[] args) {
		//saveUserData();
		//deleteUserrecord();
		//updateUserRecord();
		//saveUserDetailsUsingPSTMT();
		saveListOfUser();
	}
	
	public static void saveUserData() {
		JdbcConnection connection = new JdbcConnection();
		
		User user = new User();
		user.setId(100);
		user.setUserName("Ved");
		user.setGender("male");
		user.setMobileNo(191991919);
		user.setUserPass("ved");
		user.setUserAddress("mumbai");
		
		String msg = connection.saveUserData(user);
		System.out.println(msg);
	}
	
	public static void deleteUserrecord() {
		JdbcConnection connection = new JdbcConnection();
		String msg = connection.deleteUserRecord(100);
		System.out.println(msg);
	}
	
	public static void updateUserRecord() {
		JdbcConnection connection = new JdbcConnection();
		User user =  new User();
		user.setId(2);
		user.setMobileNo(333333333);
		user.setUserAddress("hadapsar");
		
		String msg = connection.updateUserData(user);
		System.out.println(msg);
	}
	
	public static void saveUserDetailsUsingPSTMT() {
		JdbcConnection connection = new JdbcConnection();
		
		User user = new User();
		user.setId(110);
		user.setUserName("Ved");
		user.setGender("male");
		user.setMobileNo(191991919);
		user.setUserPass("ved");
		user.setUserAddress("mumbai");
		
		String msg = connection.saveUserDataUsingPSTMT(user);
		System.out.println(msg);
	}
	
	public static void saveListOfUser() {
		
		List<User> listOfusers = new ArrayList<>();
		
		User user = new User();
		user.setId(107);
		user.setUserName("Ved");
		user.setGender("male");
		user.setMobileNo(191991919);
		user.setUserPass("ved");
		user.setUserAddress("mumbai");
		
		User user1 = new User();
		user1.setId(108);
		user1.setUserName("Ved");
		user1.setGender("male");
		user1.setMobileNo(191991919);
		user1.setUserPass("ved");
		user1.setUserAddress("mumbai");
		
		User user2 = new User();
		user2.setId(109);
		user2.setUserName("Ved");
		user2.setGender("male");
		user2.setMobileNo(191991919);
		user2.setUserPass("ved");
		user2.setUserAddress("mumbai");
		
		listOfusers.add(user);
		listOfusers.add(user1);
		listOfusers.add(user2);
		JdbcConnection connection = new JdbcConnection();
		String msg = connection.saveListOfUserDataUsingPSTMT(listOfusers);
		
		System.out.println(msg);
	}

}
