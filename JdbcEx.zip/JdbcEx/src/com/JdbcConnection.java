package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class JdbcConnection {

	public static void main(String[] args) {
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("step 1");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15", "root", "root");
		System.out.println("step 2");
		Statement stmt = conn.createStatement();
		System.out.println("step 3");
		ResultSet rs = stmt.executeQuery("select * from user");
		  System.out.println("step 4");
		  
		  while(rs.next()) {
			  System.out.println(rs.getString("id"));
			  System.out.println(rs.getString("user_name"));
			  System.out.println(rs.getString("user_address"));
			  System.out.println(rs.getString("user_pass"));
			  System.out.println(rs.getString("gender"));
			  System.out.println(rs.getString("mobile_no"));
		  }
		  
		//127.0.01
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
