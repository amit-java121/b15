package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class JdbcConnection {

	public static void main(String[] args) {
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("step 1");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15", "root", "root");
		System.out.println("step 2");
		Statement stmt = conn.createStatement();
		System.out.println("step 3");
		ResultSet rs = stmt.executeQuery("select * from user");
		  System.out.println("step 4");
		  
		  while(rs.next()) {
			  System.out.println(rs.getString("id"));
			  System.out.println(rs.getString("user_name"));
			  System.out.println(rs.getString("user_address"));
			  System.out.println(rs.getString("user_pass"));
			  System.out.println(rs.getString("gender"));
			  System.out.println(rs.getString("mobile_no"));
		  }
		  
		//127.0.01
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public List<User> getAllUserData() {
		
		List<User> listOfUser = new ArrayList<>();
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15", "root", "root");
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from user");
			 
			  while(rs.next()) {
				  User  user = new User();
				  
				  user.setId(rs.getInt("id"));
				  user.setUserName(rs.getString("user_name"));
				  user.setUserPass( rs.getString("user_pass"));
				  user.setUserAddress(rs.getString("user_address"));
				  user.setGender(rs.getString("gender"));
				  user.setMobileNo(rs.getInt("mobile_no"));

				  listOfUser.add(user);  
			  }
			  
			}catch(Exception e) {
				e.printStackTrace();
			}
		return listOfUser;
			
		}
	
	public List<User> getAllUserDataByCityName(String cityName) {
		
		List<User> listOfUser = new ArrayList<>();
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15", "root", "root");
			Statement stmt = conn.createStatement();	
			ResultSet rs = stmt.executeQuery("select * from user where user_address ='"+cityName+"'");
			 
			  while(rs.next()) {
				  User  user = new User();
				  
				  user.setId(rs.getInt("id"));
				  user.setUserName(rs.getString("user_name"));
				  user.setUserPass( rs.getString("user_pass"));
				  user.setUserAddress(rs.getString("user_address"));
				  user.setGender(rs.getString("gender"));
				  user.setMobileNo(rs.getInt("mobile_no"));

				  listOfUser.add(user);  
			  }
			  
			}catch(Exception e) {
				e.printStackTrace();
			}
		return listOfUser;
			
		}

	public User getUserDataById(int id) {
		 
		 User  user = new User();
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15", "root", "root");
		Statement stmt = conn.createStatement();	
		ResultSet rs = stmt.executeQuery("select * from user where id ="+id+"");
		
		while(rs.next()) {
			  
			  user.setId(rs.getInt("id"));
			  user.setUserName(rs.getString("user_name"));
			  user.setUserPass( rs.getString("user_pass"));
			  user.setUserAddress(rs.getString("user_address"));
			  user.setGender(rs.getString("gender"));
			  user.setMobileNo(rs.getInt("mobile_no"));
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		return user;
	}
		
	
	public String saveUserData(User user) {
		

		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15", "root", "root");
		Statement stmt = conn.createStatement();	
		 int  i = stmt.executeUpdate("insert into user values("+user.getId()+",'"+user.getUserName()+"','"+user.getUserPass()+"','"+user.getUserAddress()+"','"+user.getGender()+"',"+user.getMobileNo()+" )");
		
		 if(i>0) {
			 return "user record saved successfylly";
		 }else {
		  return "user record is not saved successfylly";
		 	}
		}catch(Exception e) {
			//e.printStackTrace();
			 return "user record is not saved successfylly "+e.getMessage();
		}
		
		
	}
	
	public String deleteUserRecord(int id) {
		

		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15", "root", "root");
		Statement stmt = conn.createStatement();	
		 int  i = stmt.executeUpdate("delete from user where id = "+id+"");
		
		 if(i>0) {
			 return "user record deleted successfylly";
		 }else {
		  return "user record is not deleted successfylly";
		 	}
		}catch(Exception e) {
			//e.printStackTrace();
			 return "user record is not deleted successfylly "+e.getMessage();
		}
		
		
	}
	
	public String  updateUserData(User user) {
		

		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15", "root", "root");
		Statement stmt = conn.createStatement();	
		 int  i = stmt.executeUpdate("update user set user_address = '"+user.getUserAddress()+"',mobile_no = "+user.getMobileNo()+" where id ="+user.getId()+" ");
		
		 if(i>0) {
			 return "user record updated successfylly";
		 }else {
		  return "user record is not updated successfylly";
		 	}
		}catch(Exception e) {
			//e.printStackTrace();
			 return "user record is not updated successfylly "+e.getMessage();
		}
		
		
	}
	
	
		
}
