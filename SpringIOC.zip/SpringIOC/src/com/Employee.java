package com;

public class Employee {
	
	public void test() {
		System.out.println("test called from class Employee::");
	}

}
