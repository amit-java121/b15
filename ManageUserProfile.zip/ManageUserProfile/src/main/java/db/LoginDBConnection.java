package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.User;

public class LoginDBConnection {
	
	public User getUserDetailByName(String username) {
		User user = null;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","root");
		
		PreparedStatement pstmt = conn.prepareStatement("select * from user_profile where user_email=?");
		pstmt.setString(1, username);
		
		ResultSet rs = pstmt.executeQuery();
		user = new User();
		while(rs.next()) {
			user.setUserEmail(rs.getString("user_email"));
			user.setUserPass(rs.getString("user_pass"));
			
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return user;
	}

	public boolean saveUserDetails(User user) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","root");
			
			PreparedStatement pstmt = conn.prepareStatement("insert into user_profile values(?,?,?,?,?,?,?)");
			
			pstmt.setInt(1, user.getUserId());
			pstmt.setString(2, user.getUserName());
			pstmt.setString(3, user.getUserPass());
			pstmt.setString(4, user.getUserEmail());
			pstmt.setLong(5, user.getContactNumber());
			pstmt.setString(6, user.getGender());
			pstmt.setString(7, user.getCountry());
			
			int i= pstmt.executeUpdate();
			if(i > 0) {
				return true;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}

}
