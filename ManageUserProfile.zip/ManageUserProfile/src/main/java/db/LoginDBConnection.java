package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.User;

public class LoginDBConnection {
	
	public User getUserDetailByName(String username) {
		User user = null;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","root");
		
		PreparedStatement pstmt = conn.prepareStatement("select * from user where user_name=?");
		pstmt.setString(1, username);
		
		ResultSet rs = pstmt.executeQuery();
		user = new User();
		while(rs.next()) {
			user.setUserName(rs.getString("user_name"));
			user.setUserPass(rs.getString("user_pass"));
			
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return user;
	}

}
