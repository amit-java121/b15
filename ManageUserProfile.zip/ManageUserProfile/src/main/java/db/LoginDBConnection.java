package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.User;

public class LoginDBConnection {
	
	public User getUserDetailByName(String username) {
		User user = null;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","root");
		
		PreparedStatement pstmt = conn.prepareStatement("select * from user_profile where user_email=?");
		pstmt.setString(1, username);
		
		ResultSet rs = pstmt.executeQuery();
		user = new User();
		while(rs.next()) {
			user.setUserEmail(rs.getString("user_email"));
			user.setUserPass(rs.getString("user_pass"));
			
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return user;
	}

	public boolean saveUserDetails(User user) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","root");
			
			PreparedStatement pstmt = conn.prepareStatement("insert into user_profile values(?,?,?,?,?,?,?)");
			
			pstmt.setInt(1, user.getUserId());
			pstmt.setString(2, user.getUserName());
			pstmt.setString(3, user.getUserPass());
			pstmt.setString(4, user.getUserEmail());
			pstmt.setLong(5, user.getContactNumber());
			pstmt.setString(6, user.getGender());
			pstmt.setString(7, user.getCountry());
			
			int i= pstmt.executeUpdate();
			if(i > 0) {
				return true;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}

	public List<User> fetchUserDetails() {
		List<User> listOfUsers = new ArrayList<User>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","root");
			
			PreparedStatement pstmt = conn.prepareStatement("select * from user_profile");
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				User user = new User();
				user.setUserId(rs.getInt(1));
				user.setUserName(rs.getString(2));
				user.setUserEmail(rs.getString(4));
				//user.setUserPass(null)
				user.setContactNumber(rs.getLong(5));
				user.setGender(rs.getString(6));
				user.setCountry(rs.getString(7));
				
				listOfUsers.add(user);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return listOfUsers;
	}

	public boolean deleteUserById(int userId) {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","root");
			
			PreparedStatement pstmt = conn.prepareStatement("delete from user_profile where user_id=?");
			pstmt.setInt(1, userId);
			int i = pstmt.executeUpdate();
			
			if(i>0) {
				return true;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}

	public User getUserDataById(int userId) {
		User user = new User();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","root");
			
			PreparedStatement pstmt = conn.prepareStatement("select * from user_profile where user_id=?");
			pstmt.setInt(1, userId);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				user.setUserId(rs.getInt(1));
				user.setUserName(rs.getString(2));
				user.setUserEmail(rs.getString(4));
				user.setContactNumber(rs.getLong(5));
				user.setGender(rs.getString(6));
				user.setCountry(rs.getString(7));
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return user;
	}

}
