package com;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.User;
import service.LoginService;

/**
 * Servlet implementation class UpdateController
 */
@WebServlet("/UpdateController")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		if(request.getParameter("userEmail") == null) {
			int userId= Integer.parseInt(request.getParameter("id"));
			
			LoginService loginService =  new LoginService();
			User user = loginService.getUserDataById(userId);
			
			if(user != null) {
				request.setAttribute("user", user);
				RequestDispatcher rd = request.getRequestDispatcher("user-edit.jsp");
				rd.forward(request, response);
			}
		}else {
			
			User user = new User();
			user.setUserId(Integer.parseInt(request.getParameter("userId")));
			user.setUserName(request.getParameter("userName"));
			user.setContactNumber(Long.valueOf(request.getParameter("userMBNumber")));
			user.setGender(request.getParameter("gender"));
			user.setCountry(request.getParameter("country"));
			
			LoginService loginService = new LoginService();
			boolean flag = loginService.updateUserDetails(user);
			
			if(flag) {
				List<User> listOfUsers = loginService.fetchAllUserData();
				request.setAttribute("list", listOfUsers);
				RequestDispatcher rd = request.getRequestDispatcher("show-user-list.jsp");
				rd.forward(request, response);	
			}else {
				request.setAttribute("message", "User record is not updated, please try again!");
				RequestDispatcher rd = request.getRequestDispatcher("user-edit.jsp");
				rd.forward(request, response);
			}
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
