package service;

import java.util.List;

import db.LoginDBConnection;
import model.User;

public class LoginService {

	public boolean verifyUserCredentials(String username, String password) {
		
		LoginDBConnection connection = new LoginDBConnection();
		User userfrmDb = connection.getUserDetailByName(username);
		//
		if(userfrmDb.getUserEmail().equalsIgnoreCase(username) && userfrmDb.getUserPass().equalsIgnoreCase(password)) {
			return true;
		}else {
			return false;
		}
		
	}

	public boolean saveUserDetails(User user) {
		LoginDBConnection connection = new LoginDBConnection();
		return connection.saveUserDetails(user);
		
	}

	public List<User> fetchAllUserData() {
		// TODO Auto-generated method stub
		LoginDBConnection connection = new LoginDBConnection();
		return connection.fetchUserDetails();
	}

	public boolean deleteUserById(int userId) {
		
		LoginDBConnection connection = new LoginDBConnection();
		return connection.deleteUserById(userId);
	}

	public User getUserDataById(int userId) {
		LoginDBConnection connection = new LoginDBConnection();
		return connection.getUserDataById(userId);
	}

}
