package com;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class TestIO {
	
	public static void main(String[] args) {
		
//		String str = "xpert it solutions "; 
//		File file = new File("C:\\Users\\Amit\\Desktop\\test.txt");
//		try {
//		FileWriter fw = new FileWriter(file, true);
//		
//		BufferedWriter bw = new BufferedWriter(fw);
//		bw.write(str+"\n");
//		bw.close();
//		
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
		
		///read
		
		
		File file = new File("C:\\Users\\Amit\\Desktop\\test.txt");
		try {
		FileReader fw = new FileReader(file);
		
		BufferedReader br = new BufferedReader(fw);
		int i=0;
		while((i = br.read()) != -1) {
			System.out.print((char)i);
		}
		
		br.close();
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
