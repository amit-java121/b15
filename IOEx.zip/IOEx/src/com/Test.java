package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test {
	
	
	public void writeIntoFile() {
		
		String str = "welcome to xpert it";
		
		try {
		File file = new File("C:\\Users\\Amit\\Desktop\\test.txt");
		FileOutputStream fis = new FileOutputStream(file);
		
		fis.write(str.getBytes());
		
		fis.close();
		
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void readFromFile() {
		
		try {
		File file = new File("C:\\Users\\Amit\\Desktop\\test.txt");
		FileInputStream fis = new FileInputStream(file);
		
		int i = 0;
		while( (i = fis.read()) != -1) {
			System.out.print((char)i);
		}
		
		}catch(IOException e) {
			e.printStackTrace();
			
		}
		
	}
	
	
	public static void main(String[] args) {
		
		Test test = new Test();
		test.writeIntoFile();
		test.readFromFile();
	}
	

}
