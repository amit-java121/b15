package garbage;

public class Test {
	
	
	@Override
	protected void finalize() {
		System.out.println("garbage colleced:::");
	}
	
	public static void main(String[] args) {
		Test test = new Test();
		Test test1 = new Test();
		
		
		//test =  null;
		test1 = null;
				
		System.gc();
		
	}

}
