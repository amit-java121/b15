package springboot.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "orders")
public class Orders {
	
	@Id
	@Column(name="order_id",nullable = false,unique = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int order_id;
	
	@Column(name = "item_name",nullable = true)
	private String itemName;
	
	@ManyToOne
	@JoinColumn(name = "customer_id")
	private NewCustomer newCustomer;

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public NewCustomer getNewCustomer() {
		return newCustomer;
	}

	public void setNewCustomer(NewCustomer newCustomer) {
		this.newCustomer = newCustomer;
	}

	@Override
	public String toString() {
		return "Orders [order_id=" + order_id + ", itemName=" + itemName + ", newCustomer=" + newCustomer + "]";
	}
	

}
