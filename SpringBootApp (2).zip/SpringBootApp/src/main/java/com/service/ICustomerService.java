package com.service;

import com.model.Customer;

public interface ICustomerService {

	Customer verifyUser(String username, String password);

	void saveUserData(Customer customer);

}
