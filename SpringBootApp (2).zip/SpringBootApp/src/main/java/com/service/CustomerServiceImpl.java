package com.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.CustomerRepository;
import com.model.Customer;
@Service
public class CustomerServiceImpl implements ICustomerService{
	
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public Customer verifyUser(String username, String password) {
		Customer customer = customerRepository.getByUserEmail(username);
		System.out.println(customer.toString());
		
		return customer;
	}

	@Override
	public void saveUserData(Customer customer) {

		customerRepository.save(customer);
		
	}

}
