package com;

//FunctionalInterface
public interface IUserInterfcae {
	public int add(int a,int b);
	
	//public void test();
	//public int sub(int a,int b);

}
