package com;


public class TestLambdaEx {
	
	public static void main(String[] args) {
		
		IUserInterfcae iu = (a,b)-> a+b;
		int sum = iu.add(10, 10);
		System.out.println(sum);
		
//		IUserInterfcae iu = () -> System.out.println("hello");
//		iu.test();
		
		
		
		
	}

}
