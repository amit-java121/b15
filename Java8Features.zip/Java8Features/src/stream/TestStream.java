package stream;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class TestStream {
	
	public static void main(String[] args) {
		
		List<Integer> list= Arrays.asList(1,2,3,4,5,6,7,8,9,11,12);
	
		//list.stream().filter(a -> a%2 == 0).forEach(System.out::println);
		//List<Integer> evenNum = list.stream().filter(a -> a%2 == 0).collect(Collectors.toList());	
		//evenNum.forEach(System.out::println);
		
		//System.out.println(evenNum);
		
		//list.stream().forEach(number -> System.out.println(number + " " + Thread.currentThread().getName()));
		list.stream().parallel().filter(a -> a%2 == 0).forEach(number -> System.out.println(number + " " + Thread.currentThread().getName()));
		
	    list.stream().parallel().filter(a -> a%2 != 0).forEachOrdered(number -> System.out.println(number + " " + Thread.currentThread().getName()));	
		
	}

}
