package stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class TestFlatMap {
	
	public static void main(String[] args) {
		
		List<List<Integer>> listOfInt = new ArrayList<>();
		List<Integer> list= Arrays.asList(1,2,3,4,5);
		List<Integer> list2= Arrays.asList(6,7,8,9,10);
		List<Integer> list3= Arrays.asList(11,12,13,14,15);
		
		listOfInt.add(list2);
		listOfInt.add(list3);
		listOfInt.add(list);
		
		System.out.println(listOfInt);
		
		List<Integer> listOfAllIntegers = listOfInt.stream().flatMap(x -> x.stream()).collect(Collectors.toList());
		System.out.println(listOfAllIntegers);
		
		Optional<Integer> ii = listOfAllIntegers.stream().min((i,j)->i.compareTo(j));
		System.out.println("ii: "+ii.get());
		
		 long count = listOfAllIntegers.stream().count();
		System.out.println(count);
	}

}
