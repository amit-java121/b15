package stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class TestMapFunction {
	
	public static void main(String[] args) {
		List<Integer> list= Arrays.asList(1,2,3,4,5,13,7,8,9,11,12);
		//List<Integer> listwith2= list.stream().map(a->a*2).collect(Collectors.toList());
		
		//System.out.println(listwith2);
		
		
		//list.stream().sorted().forEach(System.out::println);
		//list.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
	}

}
