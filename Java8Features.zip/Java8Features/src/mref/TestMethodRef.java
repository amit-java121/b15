package mref;

import java.util.ArrayList;
import java.util.List;

public class TestMethodRef {
	
	
	public static int subtract(int a,int b) {
		return a-b;
	}
	
	public static void main(String[] args) {
	
		IMethodRef mf = TestMethodRef::subtract;
		int sub= mf.sub(20, 10);
		System.out.println(sub);
		IMethodRef mf2 = (a,b)->a-b;
		int sub2= mf2.sub(30, 10);
		System.out.println(sub2);
		
//		List<String> list = new ArrayList<>();
//		list.add("Bjay");
//		list.add("Ajay");
//		list.add("Sanjay");
//		list.add("Rohan");
//		
//		list.forEach(System.out::println);
//		
//		for(String li:list) {
//			System.out.println(li);
//		}
	}

}
