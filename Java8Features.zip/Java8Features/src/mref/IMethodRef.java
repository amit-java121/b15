package mref;

public interface IMethodRef {
	public int sub(int a,int b);

}
