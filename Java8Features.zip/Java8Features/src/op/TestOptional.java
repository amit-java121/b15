package op;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TestOptional {
	
	
	public void setData() {
		
		List<String> list = null;
		
		//exception generate
		list =  new ArrayList<>();
		list.add("Bijay");
		list.add("Ajay");
		list.add("Sanjay");
		list.add("Rohan");
		
		
		
		getListData(Optional.ofNullable(list));
	}
	
	public void getListData(Optional<List<String>> optionaObject) {
		
		if(optionaObject.isPresent()) {
			List<String> list2= optionaObject.get();
			System.out.println("if executed::");
			
			
			System.out.println(list2.get(0).toUpperCase());
		}
		
		
	}
	
	public static void main(String[] args) {
		TestOptional to = new TestOptional();
		to.setData();
		
	}

}
