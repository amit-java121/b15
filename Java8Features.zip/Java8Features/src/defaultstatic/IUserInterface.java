package defaultstatic;

@FunctionalInterface
public interface IUserInterface {

	public void test();
	
	default void m1() {
		System.out.println("m1 called from User interfcae:::");
	}
	
	public static void m2() {
		System.out.println("m2 called from User interfcae:::");
	}
}
