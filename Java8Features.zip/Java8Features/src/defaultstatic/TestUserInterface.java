package defaultstatic;

public class TestUserInterface implements IUserInterface{

	@Override
	public void test() {
		System.out.println("test method called::");
		
	}
	
	@Override
	public void m1() {
		
		System.out.println("m1 called class");
		//IUserInterface.super.m1();
	}
	
	public static void main(String[] args) {
		TestUserInterface ti = new TestUserInterface();
		ti.test();
		ti.m1();
		IUserInterface.m2();
	}
	
	

}
