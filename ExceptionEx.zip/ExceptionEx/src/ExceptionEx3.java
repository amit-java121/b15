
public class ExceptionEx3 {
	
	public void m1() throws NullPointerException{

		System.out.println("before m1 called");

		String str = null;
		if (str.equals("")) {

		}

		// FileOutputStream fos = new FileOutputStream(new File("c://amit/"));

		System.out.println("m1 called:::");

	}

	
	public void m2() throws NullPointerException{
		System.out.println("before m2 called");
		m1();
		System.out.println("after m2 called");
		
	}
	
	
	
	
	public static void main(String[] args) {
		ExceptionEx3 ee =  new ExceptionEx3();
			ee.m1();
		
		
	}


}
