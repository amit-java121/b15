
public class ExceptionEx {
	
	public static void main(String[] args) {
		
		try {
			
			int a =10/0;
			System.out.println("before  finally:::");
		}finally {
			System.out.println("finally exceuted:::");
		}
		
		System.out.println("after finally :::");
		
	}

}
