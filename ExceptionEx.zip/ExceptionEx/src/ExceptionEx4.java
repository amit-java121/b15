
public class ExceptionEx4 {
	
	public void m1(int age) {
		
		if(age > 10) {
			 throw new IllegalArgumentException();
		}
		
	}

	public void m2() {
		m1(20);
	}
	
	public static void main(String[] args) {
		
		ExceptionEx4 ee4 = new ExceptionEx4();
		 ee4.m2();
	}
}
