import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ExceptionEx2 {
	
	public void m1() throws IOException {
		
		System.out.println("before m1 called");
		FileOutputStream fos = new FileOutputStream(new File("c://amit/"));
		
		System.out.println("m1 called:::");
		
	}

	
	public void m2() throws IOException {
		System.out.println("before m2 called");
		m1();
		System.out.println("after m2 called");
		
	}
	
	
	
	
	public static void main(String[] args) {
		ExceptionEx2 ee =  new ExceptionEx2();
		try {
			ee.m2();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
