
public class ExceptionTest {
	
	
	public int sub(int a,int b) {
		
		System.out.println("logic");
		int div = 0;
		try {
			
			 div = a/b;
			System.out.println(div);
			
//			String str = null;
//			
//			if(str.equals("xpertIt")) {
//				System.out.println("trueeee");
//			}
			
		}catch(ArithmeticException e) {
			//e.printStackTrace();
			System.out.println("ArithmeticException ::");
		}catch(NullPointerException e) {
			System.out.println("asasasas");
			e.printStackTrace();
			System.out.println("catch block executed Exception ");
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}finally {
			System.out.println("finally block executed:::");
		}
		
		
		System.out.println("some logic here:: ");
		
		
		
		return div;
	}

	
	public static void main(String[] args) {
		
		ExceptionTest exceptionTest = new ExceptionTest();
		int div = exceptionTest.sub(10, 2);
		
		System.out.println(div);
	}
}
