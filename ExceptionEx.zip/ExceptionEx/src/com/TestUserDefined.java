package com;

public class TestUserDefined {
	
	public String getUserDeta(int userId){
		
		if(userId == 1000) {
			return "okay";
		}else {
			
			throw new UserNotFoundException(500,"User not found please try after some time!");
		}
		
	}
	
	
	
	
	public static void main(String[] args) {
		TestUserDefined testUserDefined = new TestUserDefined();
		try {
			String msg= testUserDefined.getUserDeta(1000);
			System.out.println(msg);
		}catch(UserNotFoundException u) {
			System.out.println(u.getErrorCode()+" "+u.getErrorMessage());
		}
	}

}
