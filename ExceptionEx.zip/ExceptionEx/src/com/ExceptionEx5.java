package com;

public class ExceptionEx5 {
	
	public int test(int b,int c) {
		
		int a=0;
		try {
			
			System.out.println("try block executed:::");
			
			 a = b/c;
			
			//return a;
			
		}catch(Exception e) {
			System.out.println("catch executed::");
			//return a;
			
		}finally {
			System.out.println("finally executed::");
		}
		
		return 10;
	}

	
	public static void main(String[] args) {
		ExceptionEx5 ee = new ExceptionEx5();
		System.out.println(ee.test(10, 0));
	}
}
