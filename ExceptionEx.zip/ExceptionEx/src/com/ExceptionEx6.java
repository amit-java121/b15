package com;

public class ExceptionEx6 {
	
	public String test(String userName) {
		
		String str ="";
		
		if(userName.equalsIgnoreCase("xpertit@gmail.com")) {
			//str= userName;
			str="syccsess";
		}else {
			str="user name is not correct::";
			//throw new IllegalArgumentException("user name is not correct::");
		}
		
		
		return str;
	}
	
	public static void main(String[] args) {
		ExceptionEx6 ee = new ExceptionEx6();
		// try {
		  ee.test("abaabba");
//		 }catch(Exception e) {
//			 System.out.println(e.getMessage());
//		 }
	}

}
