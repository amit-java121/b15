package com;

public class StringEx2 {
	
	public static void main(String[] args) {
		
		String str = "Hello";
		String str1 = "hello";
		
		String st = new String("Hello");
		
		String st1 = new String("Hello xpertit");
		
		
		System.out.println(str.equalsIgnoreCase(str1));
		
		System.out.println(str.equals(st));//true
		System.out.println(str1.equals(st));//false
		
		System.out.println(st == st1);//false
		
		System.out.println(str1 == st);//false
		
		
	}

}
