package constt.fin;

public class A {
	
	public void m1() {
		System.out.println("m1 called form class A");
	}

}
