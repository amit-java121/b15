package constt.fin;

public class TestCustomer {
	
	public Customer setData() {
		Customer customer = new Customer(19199191, "xpertit", "pune");
		 return customer;
	}
	
	
	public void printData() {
		Customer customer = setData();
		
		customer.setCustomerName("abc");
		
		System.out.println(customer.getCutomerPANNumber());
		
	}
	
	public static void main(String[] args) {
		
		TestCustomer testCustomer = new TestCustomer();
		testCustomer.printData();
		
		
	}

}
