package constt.fin;

public class FinalEx {
	
	//final int aa = 100;
	final int bb;
	
//	{
//		bb =400;
//	}
	
	public void m1() {
		//bb =100;
		//aa = 200;
	}
	
	public FinalEx() {
		bb =300;
		//aa = 300;
	}
	
	public static void main(String[] args) {
		
	}

}
