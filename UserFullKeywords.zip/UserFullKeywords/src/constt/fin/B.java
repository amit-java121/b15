package constt.fin;

public class B  extends A{
	
	public void m2() {
		System.out.println("m2 called form class B");
	}
	
	public static void main(String[] args) {
		B b = new B();
		b.m1();
	}

}
