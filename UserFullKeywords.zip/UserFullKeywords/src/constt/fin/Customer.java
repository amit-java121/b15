package constt.fin;

public class Customer {
	
	private final int cutomerPANNumber;
	private String customerName;
	private String cutomerAddress;
	

	public Customer(int cutomerPANNumber, String customerName, String cutomerAddress) {
		super();
		this.cutomerPANNumber = cutomerPANNumber;
		this.customerName = customerName;
		this.cutomerAddress = cutomerAddress;
	}
	
	
	public int getCutomerPANNumber() {
		return cutomerPANNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCutomerAddress() {
		return cutomerAddress;
	}
	public void setCutomerAddress(String cutomerAddress) {
		this.cutomerAddress = cutomerAddress;
	}
	
	
	

}
