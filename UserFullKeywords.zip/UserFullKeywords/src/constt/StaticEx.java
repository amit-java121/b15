package constt;

public class StaticEx {
	
	static int aa =10;
	int num =100;
	 String str ="xpertit";
	
	public static void m1() {
		
		int bb =30;
		
	}
	
	public void m2() {
		m1();
	}


}
