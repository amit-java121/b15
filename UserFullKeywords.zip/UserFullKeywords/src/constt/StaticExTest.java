package constt;

public class StaticExTest {
	
	public static void main(String[] args) {
		
//		StaticEx staticEx = new StaticEx();
//		staticEx.m2();
		StaticEx.m1();	
		
	}

}
