package constt;

public class StaticBlockEx {
	
	 static int aa; 
	 int bb ;
	
	static {
		aa = 200;
		System.out.println("static block executed::");
		
	}
	
	
	{
		bb = 300;
		System.out.println("init block called::");
	}
	
	public StaticBlockEx() {
		//aa = 100;
		System.out.println("const called::");
	}
	
	
	
	public static void main(String[] args) {
		System.out.println("aaa : "+StaticBlockEx.aa);
		StaticBlockEx staticBlockEx = new StaticBlockEx();
		System.out.println(staticBlockEx.aa);
		
	}

}
