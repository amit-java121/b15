package constt;

public class ConstructorTest {
	
	int id;
	String name;
	
	public ConstructorTest() {
		System.out.println("default const:::");
	}
	
	public ConstructorTest(int a) {
		this();
		System.out.println("param const::");
		
		id = a;
	}
	
	
	public ConstructorTest(int a,String str) {
		this(100);
		System.out.println("param const::");
		id = a;
		name = str;
	}
	
	public static void main(String[] args) {
		
		ConstructorTest constructorTest1 = new ConstructorTest();
		
		ConstructorTest constructorTest = new ConstructorTest(100);
		
		ConstructorTest constructorTest2 = new ConstructorTest(100,"xpertit");
		
		System.out.println(constructorTest.name);
	}

}
