package com;

public class Test {
	
	int a =10;
	int b = 20;
	String str = "hello";
	
	char c = 'a';
	
	boolean flag;
	
	
	static int dd =100;
	
	
	void add(){
		int cc = 30;//local variable
		int sum = a+b;
		System.out.println(sum);
		
		//
		 int mu = multiplication();
		
		 System.out.println(sum+mu);
		 
		//
		//System.out.println(mu);
		
	}
	
	int multiplication() {
		
		int multi = a*b;
		
		//System.out.println(multi);
		
		return multi;
	}
	
  public static void main(String[] args) {
	  
	  Test test = new Test();
	  Test test1 = new Test();
	  Test test2 = new Test();
	  
	  test.add();
	  System.out.println(test.a);
	  System.out.println(test1.a);
	  System.out.println(Test.dd);
	
  }

}
